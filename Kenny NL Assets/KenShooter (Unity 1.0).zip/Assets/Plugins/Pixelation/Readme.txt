README - Pixelation image effect
---------------------------------

by DMITRY TIMOFEEV
https://assetstore.unity.com/packages/vfx/shaders/fullscreen-camera-effects/pixelation-65554

Version: 1.0


Usage effect Pixelation:
* Add Pixelation script to a camera.
* Or select Menu -> Component -> Image Effects -> Color Adjustments -> Pixelation
* Set the shader Pixelation. 
* Set the number of pixel blocks.
* Enjoy!

Usage effect Chunky:
* Add Chunky script to a camera.
* Or select Menu -> Component -> Image Effects -> Color Adjustments -> Chunky
* Set the shader Chunky.
* Set the SprTex texture chunky4x4_16. 
* Change Color.
* Enjoy!
