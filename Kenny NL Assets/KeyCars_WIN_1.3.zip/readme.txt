

	---

	KeyCars 1.3 by Kenney (www.kenney.nl)

	---

	# Distribution:  This game is distributed for free at www.kenney.nl/games/keycars.
	# License: 	 You're free to distribute this copy and create gameplay videos, commercial use permitted.

	---

	Instructions:

	Press any (letter) key on the keyboard to join the game, press and hold the chosen key to rotate the vehicle.
	Drive into other player vehicles to destroy them.

	Yellow pad:	Temporary speed boost
	Blue pad:	Shoot projectile
	Red pad:	Switch control direction
	Turquoise pad:	Jump

	Press SPACEBAR during gameplay to spawn a CPU player.